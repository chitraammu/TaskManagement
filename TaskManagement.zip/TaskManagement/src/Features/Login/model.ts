export type State ={
   userData:userData[];
}
interface userData{
    emailId:string;
    password:string;
}