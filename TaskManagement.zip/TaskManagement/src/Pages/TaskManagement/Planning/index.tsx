import React from "react";
import { Outlet } from "react-router";

function Planning(){
  return(
    <div>
        <Outlet />
    </div>
  )
}

export default Planning;